import re
pos=0
f = open('input.txt', 'r')
f1=open('assignmentfinal_output.txt','a+')
for line in f:
    line=line.lower()
    s = re.findall('[aeiouAEIOU]{2,}', line)
    for item in s:
        line = line.replace(item, item[::-1])
    line1 = list(line)
    length=len(line1)
    new_str = ''
    i = 0
    while i<len(line1)-1:
        if line1[i] not in '[^aeiouAEIOU]':
            if line1[i] != line1[i + 1]:
                new_str = new_str + line1[i]
                i = i + 1
            else:
                char = line1[i]
                for j in range(i + 1, len(line1)):
                    if char != line1[j]:
                        pos = j
                        break
                i = pos
                new_str = new_str + line1[i-1]
        else:
            new_str = new_str + line1[i]
            i=i+1

    f1.write(new_str+'\n')
f.close()
f1.close()













