f = open('input.txt', 'r+')
f1=open('assignment_final_output.txt','a+')
for line in f:
    new_line = ''
    for word in line:
        if '\n' not in word:
            if word == ' ':
                new_line = word + new_line
            else:
                new_line = word + new_line
        else:
            word = word.split('\n')
            new_line = word[0] + new_line
    new_line1 = new_line.split(' ')
    new_str = ''
    for each_word in new_line1:
        if ',' in each_word:
            word1 = each_word.partition(',')
            for item in word1:
                item1=item[::-1]
                new_str = new_str + ' ' + item1
        else:
            eachword = each_word[::-1]
            new_str = new_str + ' ' + eachword

    f1.write(new_str+'\n')
f.close()
f1.close()